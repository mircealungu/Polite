Helvetia 1.0

- Mac: launch Helvetia.app
- Linux: launch Helvetia.sh
- Windows: launch Helvetia.lnk

This distribution was built July 10, 2012.
